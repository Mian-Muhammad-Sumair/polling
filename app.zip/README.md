
## Polling

#Dev Installation

`git clone`

`cp .env.example .env`

`php artisan key:generate`

`composer install`

`php artisan server`

`http://127.0.0.1:8000`
