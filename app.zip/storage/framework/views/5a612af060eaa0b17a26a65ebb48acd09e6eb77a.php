
<?php $__env->startSection('title'); ?>
    Register
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class=" content-order animatedParent">
    <div class="row">
        <div class="col-md-6 images animated bounceInLeft ">
            <img class="" src="<?php echo e(asset('assets/images/register.png')); ?>" alt="image">
        </div>
        <div class="col-md-6 animated bounceInRight">
            <div class="login-bg register-bg animatedParent">
                <div class="main">
                    <h2 class="title-page" ><?php echo e(__('Register')); ?></h2>
                    <div class="theme-bar"></div>
                </div>
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_type" value="<?php echo e(request()->segment(1)=='register'?'customer':request()->segment(1)); ?>">
                    <div class="form-group">
                        <label><?php echo e(__('Name')); ?> </label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error_msg"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('E-Mail Address')); ?> </label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error_msg"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('Password')); ?> </label>
                        <input type="password" name="password" required autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error_msg"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('Confirm Password')); ?></label>
                        <input type="password" name="password_confirmation" required autocomplete="new-password">
                    </div>
                    <div class="form-group text-right">
                        <button type="submit"><?php echo e(__('Register')); ?></button>
                    </div>
                    <div  class="text-center create clr-wt pd-10">Already have an account? <a class="clr-wt" href="<?php echo e(url(request()->segment(1)=='register'?'/login':request()->segment(1).'/login')); ?>">Login</a></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
        .images img{
            float: right;
        }
        .login-bg{
            padding-left: 50px;
        }
        .title-page{
            font-weight: 600;
        }
        .page-title{
            width: 17%;
        }
        .main{
            margin-bottom: 10px;
        }
        .theme-bar{
            width: 10%;
            height: 4px;
            background-color: #7158F4;
            margin-bottom: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/auth/register.blade.php ENDPATH**/ ?>