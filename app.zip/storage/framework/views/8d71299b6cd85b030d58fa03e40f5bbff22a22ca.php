
<script src="<?php echo e(asset('assets/js/lib/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/css3-animate-it.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/counter.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/owl.carousel.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/includes/js_links.blade.php ENDPATH**/ ?>