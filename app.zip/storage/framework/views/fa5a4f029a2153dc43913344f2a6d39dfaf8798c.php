<header class="transparent">
    <div class="container" style="width: 85%">
        <div class="row">
            <div class="col-md-2 col-lg-2 col-sm-4">
                <?php if(request()->is('home')): ?>
                    <div class="logo"><a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('assets/images/logo-white.png')); ?>" alt="logo"></a></div>
                <?php else: ?>
                    <div class="logo"><a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('assets/images/logo1.png')); ?>" alt="logo"></a></div>
                <?php endif; ?>
            </div>
            <div class="col-md-10 col-lg-10 col-sm-8">
                <div class="button-header">
                    <?php if(auth()->guard(session('auth.current'))->guest()): ?>
                    <a href="<?php echo e(url('register')); ?>" class="custom-btn login">Sign Up</a>
                        <a href="<?php echo e(url('/login')); ?>" class="custom-btn">Poll Participation </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"  class="custom-btn login"><?php echo e(__('Logout')); ?></a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/includes/header.blade.php ENDPATH**/ ?>