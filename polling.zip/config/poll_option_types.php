<?php
return [
    'allow_multiple_votes'=>'Allow multiple votes',
    'login_to_vote'=>'Login to vote'
];
