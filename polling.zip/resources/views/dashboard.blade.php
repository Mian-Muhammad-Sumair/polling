@extends('layouts.app')
@section('title')
    Dashboard
@endsection
@section('extra_css')
    <style>
    </style>
@endsection
@section('content')

@endsection
