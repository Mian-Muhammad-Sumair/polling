<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container login-container content-order animatedParent" >
    <div class="row">
        <div class="col-md-6 col-sm-7  animated bounceInRight">
            <div class="login-bg login-form register-bg animatedParent">
                <div class="main">
                    <h2 class="title-page" ><?php echo e(__('Login')); ?></h2>
                    <div class="theme-bar"></div>
                </div>
                <form method="POST" action="<?php echo e(url(request()->segment(1)=='login'?'/customer/login':request()->segment(1).'/login')); ?>" style="float: right">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><?php echo e(__('E-Mail Address')); ?> </label>
                        <input type="text" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error_msg"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label>Password </label>
                        <input type="password" name="password" required autocomplete="current-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error_msg"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group text-right">
                        <button><?php echo e(__('Login')); ?></button>
                    </div>
                    <div  class="text-center create clr-wt pd-10">Dont have account? <a class="clr-wt" href="<?php echo e(url(request()->segment(1)=='login'?'/register':request()->segment(1).'/register')); ?>"><strong>Register</strong></a></div>
                    <div  class="text-center create clr-wt pd-10">Just wanna participate in a poll? <a class="clr-wt" href="<?php echo e(url('/')); ?>"><strong>Poll Participation</strong></a></div>
                    <?php if(Route::has('password.request')): ?>
                        <div  class="text-center create clr-wt pd-10"><?php echo e(__('Forgot Your Password?')); ?> <a class="clr-wt" href="<?php echo e(route('password.request')); ?>"><strong><?php echo e(__('Click Here')); ?></strong></a></div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <div class="col-md-6 col-sm-5 login-img image animated bounceInLeft">
            <img src="<?php echo e(asset('assets/images/login.svg')); ?>" alt="image">
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
        .title-page{
            font-weight: 600;
        }
        .main{
            margin-bottom: 10px;
        }
        .theme-bar{
            width: 10%;
            height: 4px;
            background-color: #7158F4;
            margin-bottom: 20px;
        }

        .page-title .main{
            float: right;
            margin-bottom: 40px;
        }
        .login-container{
            width: 100%;
        }

        .error_msg{
            color: #0a0550;
            display: block;
            margin-top: 10px;
            font-weight: 600;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/auth/login.blade.php ENDPATH**/ ?>