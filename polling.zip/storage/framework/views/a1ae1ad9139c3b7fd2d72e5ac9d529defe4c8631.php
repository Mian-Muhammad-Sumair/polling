<?php $__env->startSection('title'); ?>
    Polls List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Polls List</div>

                    <div class="panel-body">
                        <table class="table" id="datatable">
                            <thead>
                            <tr>
                                <th>First name</th>
                                <th>info</th>
                                <th>Category</th>
                                <th>Visibility</th>
                                <th>Question</th>
                                <th>Status</th>
                                <th>Start_date</th>
                                <th>End_date</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($poll->name); ?></td>
                                    <td><?php echo e($poll->info); ?></td>
                                    <td><?php echo e($poll->category); ?></td>
                                    <td><?php echo e($poll->visibility); ?></td>
                                    <td><?php echo e($poll->question); ?></td>
                                    <td><?php echo e($poll->status); ?></td>
                                    <td><?php echo e($poll->start_date); ?></td>
                                    <td><?php echo e($poll->end_date); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" charset="utf8" src="cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready( function () {
            $('#datatable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_css'); ?>
    <link rel="stylesheet" type="text/css" href="cdn.datatables.net/1.10.16/css/jquery.dataTables.css">
    <style>
    </style>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/poll/pollList.blade.php ENDPATH**/ ?>