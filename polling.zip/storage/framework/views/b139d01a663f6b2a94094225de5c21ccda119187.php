<?php $__env->startSection('title'); ?>
    Poll Participation
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container  participation-section  content-order animatedParent" >
        <div class="row">
            <div class="col-md-6 col-sm-7  animated bounceInRight">
                <div class="login-bg login-form participation-form register-bg animatedParent">
                    <div class="main">
                        <h2 class="title-page">Poll Participation</h2>
                        <div class="theme-bar"></div>
                    </div>
                    <form  action="<?php echo e(url('/')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Enter Polling key </label>
                            <input type="text" name="polling_key"  value="<?php echo e(old('polling_key')); ?>" >
                            <?php $__errorArgs = ['polling_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error_msg"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="form-group text-right">
                            <button>Participate a poll</button>
                        </div>
                        <div  class="text-center create clr-wt pd-10">Already have an account? <a class="clr-wt" href="<?php echo e(url('/login')); ?>"><strong>Login</strong></a></div>
                        </form>
                </div>
            </div>
            <div class="col-md-6 col-sm-5 participation-img login-img image animated bounceInLeft">
                <img src="<?php echo e(asset('assets/images/login.svg')); ?>" alt="image">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
        .title-page{
            font-weight: 600;
        }
        .main{
            margin-bottom: 10px;
        }
        .theme-bar{
            width: 10%;
            height: 4px;
            background-color: #7158F4;
            margin-bottom: 20px;
        }


        .page-title .main{
            float: right;
            margin-bottom: 40px;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/pollParticipation.blade.php ENDPATH**/ ?>