<?php $__env->startSection('title'); ?>
    Create Poll
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container create-pool animatedParent">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12  animated bounceInLeft">
                <div class="main-heading">
                    <h3><?php echo e($poll['name']); ?></h3>
                </div>
                <div  class="heading">
                    <h3><?php echo e($poll['question']); ?></h3>
                    <p>Poll offered by <?php echo e($creator_name); ?> from <?php echo e($poll['start_date']); ?> to <?php echo e($poll['end_date']); ?></p>
                </div>


            </div>
            <form method="post" action="<?php echo e(url('/voting')); ?>">
                <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $poll['questionsOptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12 col-sm-12 col-lg-12 checkbox  animated bounceInRight">
                <input type="checkbox" name="answer" value="<?php echo e($option['id']); ?>" id="vote<?php echo e($index); ?>" >
                <label class="progress-card "  for="vote<?php echo e($index); ?>">
                    <div class="text"><h2><?php echo e($option['question_option']); ?></h2></div>
                    <div class="progress">
                        <div class="progress-bar bg-info progress-bar-custom-theme" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        <div class="progress-bar" role="progressbar" aria-valuenow="3" aria-valuemin="10" aria-valuemax="100"></div>
                    </div>
                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error_msg"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


















            <div class="col-md-12 col-sm-12 col-lg-12  animated bounceInLeft">
                <div class="button-header">
                    <div class="main-btn">

                    <button class="custom-btn submit">Submit your vote</button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
       .checkbox input{
            display: none;
        }
        .container{
            width: 80%;
        }
        .progress-card{
            padding:10px 30px;
            background-color: #F5F5F5;
            width: 60%;
            border-radius: 10px;
            margin-bottom: 15px;
            margin-top: 15px;
            -webkit-transition-property: color, background-color,  border;
            -webkit-transition-duration: 400ms, 400ms, 400ms, 400ms;
            border:2px solid #F5F5F5;

        }
        .create-pool .button-header{
            width: 60%;
        }
        .progress-card:hover{
            transition-timing-function: linear;
            border:2px solid #7158f4;
            background-color: white;
        }
       .checkbox input:checked +  .progress-card{
           border:2px solid #7158f4;
       }
        .progress{
            box-shadow: inset 0 0px 0px rgb(0 0 0);
        }

        .progress-card:hover .progress{
            background-color: white;
        }
        .progress-bar-custom-theme{
            background-color: #7158f4;
        }

        .progress-card .text h2{
            font-size: 28px;
        }
        .progress-card .text{
            margin-bottom: 10px;
        }
        .progress-bar{
            height: 30%;
            border-radius: 20px;
            margin-left:5px;
        }
        .main-heading{
            margin-bottom: 20px;
        }
        .main-heading h3{
            font-size: 30px;
            font-weight: 800;
        }
        .heading{
            margin-bottom: 40px;
        }
        .heading p{
            color: #333333;
        }
        .heading h3{
            font-size: 22px;
            font-weight: 800;
        }
        .next{
            background: white;
            color: #4F54A0;
            border: 2px solid #4F54A0;
            font-weight: 600;
        }
        .main-btn{
            float: right;
            margin-top:10px;
        }
        .main-btn .custom-btn{
            margin-left: 10px;
        }

        .next:hover{
            color: #2f3471;
        }
        .submit{
            background: #4F54A0;
            color: white;
            font-weight: 600;
            -webkit-transition-property:background;
            -webkit-transition-duration: 400ms, 400ms, 400ms, 400ms;
        }
        .submit:hover{
            background: #1e225e;
            color: white;
        }
        @media  only screen and (max-width:1500px) {
            .progress-card, .button-header{
                width: 70% !important;
            }
        }
        @media  only screen and (max-width:991px) {
            .progress-card,.button-header{
                width: 80% !important;
            }
            .container{
                width: 90%;
            }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pooling_live\resources\views/createPoll.blade.php ENDPATH**/ ?>